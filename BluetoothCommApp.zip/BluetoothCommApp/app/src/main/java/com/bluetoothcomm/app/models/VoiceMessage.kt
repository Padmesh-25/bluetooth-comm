package com.bluetoothcomm.app.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.UUID

@Parcelize
data class VoiceMessage(
    val messageId: String = UUID.randomUUID().toString(),
    val senderId: String,
    val senderName: String,
    val senderUsername: String = "",
    val senderDisplayName: String = "",
    val channelId: String,
    val audioData: ByteArray,
    val duration: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val audioFormat: AudioFormat = AudioFormat.PCM_16BIT,
    val sampleRate: Int = 44100,
    val isCompressed: Boolean = false
) : Parcelable {

    fun getSpeakerIdentifier(): String {
        return when {
            senderDisplayName.isNotEmpty() && senderDisplayName != senderUsername -> 
                "$senderDisplayName ($senderUsername)"
            senderUsername.isNotEmpty() -> senderUsername
            else -> senderName
        }
    }
    
    fun getShortSpeakerName(): String {
        return when {
            senderDisplayName.isNotEmpty() -> senderDisplayName
            senderUsername.isNotEmpty() -> senderUsername
            else -> senderName
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as VoiceMessage

        if (messageId != other.messageId) return false
        if (senderId != other.senderId) return false
        if (senderName != other.senderName) return false
        if (channelId != other.channelId) return false
        if (!audioData.contentEquals(other.audioData)) return false
        if (timestamp != other.timestamp) return false
        if (duration != other.duration) return false

        return true
    }

    override fun hashCode(): Int {
        var result = type.hashCode()
        result = 31 * result + messageId.hashCode()
        result = 31 * result + senderId.hashCode()
        result = 31 * result + senderName.hashCode()
        result = 31 * result + channelId.hashCode()
        result = 31 * result + audioData.contentHashCode()
        result = 31 * result + timestamp.hashCode()
        result = 31 * result + duration.hashCode()
        return result
    }
}
