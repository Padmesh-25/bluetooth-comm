package com.bluetoothcomm.app.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MusicTrack(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val filePath: String,
    val albumArt: String? = null,
    val dateAdded: Long = System.currentTimeMillis()
) : Parcelable

@Parcelize
data class Playlist(
    val id: String,
    val name: String,
    val description: String = "",
    val tracks: MutableList<MusicTrack> = mutableListOf(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isShared: Boolean = false
) : Parcelable
