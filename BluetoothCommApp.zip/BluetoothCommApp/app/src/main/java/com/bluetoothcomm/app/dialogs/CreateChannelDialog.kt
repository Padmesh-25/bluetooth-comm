package com.bluetoothcomm.app.dialogs

import android.app.Dialog
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.bluetoothcomm.app.R

class CreateChannelDialog(
    private val onChannelCreated: (name: String, isPrivate: Boolean, password: String?) -> Unit
) : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val view = layoutInflater.inflate(R.layout.dialog_create_channel, null)
        
        val editChannelName = view.findViewById<EditText>(R.id.edit_channel_name)
        val checkPrivate = view.findViewById<CheckBox>(R.id.check_private)
        val editPassword = view.findViewById<EditText>(R.id.edit_password)
        val btnCreate = view.findViewById<Button>(R.id.btn_create)
        val btnCancel = view.findViewById<Button>(R.id.btn_cancel)
        
        checkPrivate.setOnCheckedChangeListener { _, isChecked ->
            editPassword.visibility = if (isChecked) android.view.View.VISIBLE else android.view.View.GONE
        }
        
        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Create Voice Channel")
            .setView(view)
            .create()
        
        btnCreate.setOnClickListener {
            val channelName = editChannelName.text.toString().trim()
            val isPrivate = checkPrivate.isChecked
            val password = if (isPrivate) editPassword.text.toString().trim() else null
            
            if (channelName.isNotEmpty()) {
                onChannelCreated(channelName, isPrivate, password)
                dialog.dismiss()
            } else {
                editChannelName.error = "Channel name is required"
            }
        }
        
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        
        return dialog
    }
}
