package com.bluetoothcomm.app.voice

import android.app.Service
import android.content.Intent
import android.media.*
import android.os.Binder
import android.os.IBinder
import android.util.Log
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean

class VoiceService : Service() {
    
    companion object {
        private const val TAG = "VoiceService"
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val BUFFER_SIZE = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
    }
    
    private val binder = LocalBinder()
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private val isRecording = AtomicBoolean(false)
    private val isPlaying = AtomicBoolean(false)
    private var recordingThread: Thread? = null
    private var playbackThread: Thread? = null
    private var isMuted = AtomicBoolean(false)
    private var currentVolume = 1.0f
    
    private var onAudioDataCallback: ((ByteArray) -> Unit)? = null
    
    inner class LocalBinder : Binder() {
        fun getService(): VoiceService = this@VoiceService
    }
    
    override fun onBind(intent: Intent): IBinder {
        return binder
    }
    
    override fun onCreate() {
        super.onCreate()
        initializeAudioTrack()
    }
    
    private fun initializeAudioTrack() {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
            
        val audioFormat = AudioFormat.Builder()
            .setSampleRate(SAMPLE_RATE)
            .setEncoding(AUDIO_FORMAT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
            
        val bufferSize = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AUDIO_FORMAT
        )
        
        audioTrack = AudioTrack(
            audioAttributes,
            audioFormat,
            bufferSize,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )
    }
    
    fun startRecording(onAudioData: (ByteArray) -> Unit) {
        startContinuousRecording(onAudioData)
    }
    
    fun startContinuousRecording(onAudioData: (ByteArray) -> Unit) {
        if (isRecording.get()) {
            Log.w(TAG, "Already recording")
            return
        }
        
        onAudioDataCallback = onAudioData
        
        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                BUFFER_SIZE * 2
            )
            
            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord initialization failed")
                return
            }
            
            audioRecord?.startRecording()
            isRecording.set(true)
            
            recordingThread = Thread {
                recordAudioContinuously()
            }.apply { start() }
            
            Log.d(TAG, "Continuous recording started")
            
        } catch (e: SecurityException) {
            Log.e(TAG, "Permission denied for audio recording", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting recording", e)
        }
    }
    
    private fun recordAudio() {
        recordAudioContinuously()
    }
    
    private fun recordAudioContinuously() {
        val buffer = ByteArray(BUFFER_SIZE)
        val audioDataStream = ByteArrayOutputStream()
        var lastTransmissionTime = System.currentTimeMillis()
        val transmissionInterval = 500L // Send audio chunks every 500ms for continuous transmission
        
        while (isRecording.get()) {
            val bytesRead = audioRecord?.read(buffer, 0, buffer.size) ?: 0
            
            if (bytesRead > 0) {
                audioDataStream.write(buffer, 0, bytesRead)
                
                // Apply noise reduction and compression
                val processedData = processAudioData(buffer.copyOf(bytesRead))
                
                // Send audio data at regular intervals for continuous transmission
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastTransmissionTime >= transmissionInterval || 
                    audioDataStream.size() >= BUFFER_SIZE * 8) {
                    
                    val audioData = audioDataStream.toByteArray()
                    if (audioData.isNotEmpty()) {
                        onAudioDataCallback?.invoke(audioData)
                        audioDataStream.reset()
                        lastTransmissionTime = currentTime
                    }
                }
            }
        }
        
        // Send remaining data
        if (audioDataStream.size() > 0) {
            onAudioDataCallback?.invoke(audioDataStream.toByteArray())
        }
    }
    
    fun stopRecording() {
        if (!isRecording.get()) {
            return
        }
        
        isRecording.set(false)
        
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
            
            recordingThread?.join(1000)
            recordingThread = null
            
            Log.d(TAG, "Recording stopped")
            
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recording", e)
        }
    }
    
    fun playAudio(audioData: ByteArray) {
        if (isPlaying.get() || isMuted.get()) {
            if (isMuted.get()) {
                Log.d(TAG, "Audio playback muted")
            } else {
                Log.w(TAG, "Already playing audio")
            }
            return
        }
        
        playbackThread = Thread {
            try {
                isPlaying.set(true)
                
                audioTrack?.let { track ->
                    if (track.state == AudioTrack.STATE_INITIALIZED) {
                        track.play()
                        track.setVolume(currentVolume)
                        
                        // Process and play audio data
                        val processedData = processReceivedAudioData(audioData)
                        track.write(processedData, 0, processedData.size)
                        
                        // Wait for playback to complete
                        Thread.sleep((processedData.size * 1000L) / (SAMPLE_RATE * 2))
                        
                        track.pause()
                        track.flush()
                    }
                }
                
            } catch (e: Exception) {
                Log.e(TAG, "Error playing audio", e)
            } finally {
                isPlaying.set(false)
            }
        }.apply { start() }
    }
    
    private fun processAudioData(audioData: ByteArray): ByteArray {
        // Apply basic noise reduction and normalization
        val processedData = ByteArray(audioData.size)
        
        for (i in audioData.indices step 2) {
            if (i + 1 < audioData.size) {
                // Convert bytes to 16-bit sample
                val sample = (audioData[i].toInt() and 0xFF) or 
                           ((audioData[i + 1].toInt() and 0xFF) shl 8)
                
                // Apply simple noise gate
                val processedSample = if (Math.abs(sample) < 500) {
                    0
                } else {
                    // Apply gain control
                    (sample * 0.8).toInt().coerceIn(-32768, 32767)
                }
                
                // Convert back to bytes
                processedData[i] = (processedSample and 0xFF).toByte()
                processedData[i + 1] = ((processedSample shr 8) and 0xFF).toByte()
            }
        }
        
        return processedData
    }
    
    private fun processReceivedAudioData(audioData: ByteArray): ByteArray {
        // Apply decompression and enhancement for received audio
        val processedData = ByteArray(audioData.size)
        
        for (i in audioData.indices step 2) {
            if (i + 1 < audioData.size) {
                // Convert bytes to 16-bit sample
                val sample = (audioData[i].toInt() and 0xFF) or 
                           ((audioData[i + 1].toInt() and 0xFF) shl 8)
                
                // Apply volume boost for better clarity
                val processedSample = (sample * 1.2).toInt().coerceIn(-32768, 32767)
                
                // Convert back to bytes
                processedData[i] = (processedSample and 0xFF).toByte()
                processedData[i + 1] = ((processedSample shr 8) and 0xFF).toByte()
            }
        }
        
        return processedData
    }
    
    fun setVolume(volume: Float) {
        currentVolume = volume.coerceIn(0f, 1f)
        isMuted.set(currentVolume == 0f)
        audioTrack?.setVolume(currentVolume)
    }
    
    fun isMuted(): Boolean {
        return isMuted.get()
    }
    
    fun toggleMute(): Boolean {
        val newVolume = if (isMuted.get()) 1.0f else 0.0f
        setVolume(newVolume)
        return isMuted.get()
    }
    
    fun isCurrentlyRecording(): Boolean = isRecording.get()
    
    fun isCurrentlyPlaying(): Boolean = isPlaying.get()
    
    override fun onDestroy() {
        super.onDestroy()
        
        stopRecording()
        
        if (isPlaying.get()) {
            isPlaying.set(false)
            playbackThread?.interrupt()
        }
        
        audioTrack?.release()
        audioTrack = null
        
        Log.d(TAG, "VoiceService destroyed")
    }
}
