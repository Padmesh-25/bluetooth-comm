package com.bluetoothcomm.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bluetoothcomm.app.R
import com.bluetoothcomm.app.models.SearchResult

class SearchResultsAdapter(
    private val searchResults: List<SearchResult>,
    private val onResultClick: (SearchResult) -> Unit
) : RecyclerView.Adapter<SearchResultsAdapter.SearchResultViewHolder>() {

    class SearchResultViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val locationIcon: ImageView = itemView.findViewById(R.id.icon_location_type)
        val locationName: TextView = itemView.findViewById(R.id.text_location_name)
        val locationAddress: TextView = itemView.findViewById(R.id.text_location_address)
        val locationDistance: TextView = itemView.findViewById(R.id.text_location_distance)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchResultViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_search_result, parent, false)
        return SearchResultViewHolder(view)
    }

    override fun onBindViewHolder(holder: SearchResultViewHolder, position: Int) {
        val result = searchResults[position]
        
        // Set location icon based on type
        val iconRes = when (result.type.lowercase()) {
            "restaurant", "cafe", "fast_food" -> android.R.drawable.ic_menu_eat
            "fuel", "gas_station" -> android.R.drawable.ic_menu_compass
            "hospital", "pharmacy" -> android.R.drawable.ic_menu_help
            "hotel", "motel" -> android.R.drawable.ic_menu_gallery
            "shop", "store" -> android.R.drawable.ic_menu_shopping
            else -> android.R.drawable.ic_menu_mylocation
        }
        holder.locationIcon.setImageResource(iconRes)
        
        // Extract main name from display name
        val mainName = result.displayName.split(",").firstOrNull() ?: result.displayName
        holder.locationName.text = mainName
        
        // Show address (everything after first comma)
        val addressParts = result.displayName.split(",").drop(1)
        holder.locationAddress.text = if (addressParts.isNotEmpty()) {
            addressParts.joinToString(", ").trim()
        } else {
            "Location"
        }
        
        // Show distance if available
        if (result.distance > 0) {
            val distanceText = if (result.distance < 1000) {
                "${result.distance.toInt()}m"
            } else {
                "${(result.distance / 1000).toInt()}km"
            }
            holder.locationDistance.text = distanceText
            holder.locationDistance.visibility = View.VISIBLE
        } else {
            holder.locationDistance.visibility = View.GONE
        }
        
        holder.itemView.setOnClickListener {
            onResultClick(result)
        }
    }

    override fun getItemCount() = searchResults.size
}
