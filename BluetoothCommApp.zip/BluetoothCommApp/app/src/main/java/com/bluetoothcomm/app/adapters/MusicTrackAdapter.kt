package com.bluetoothcomm.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bluetoothcomm.app.R
import com.bluetoothcomm.app.models.MusicTrack

class MusicTrackAdapter(
    private var tracks: MutableList<MusicTrack>,
    private val onTrackClick: (MusicTrack) -> Unit
) : RecyclerView.Adapter<MusicTrackAdapter.TrackViewHolder>() {

    class TrackViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val trackTitle: TextView = itemView.findViewById(R.id.text_track_title)
        val trackArtist: TextView = itemView.findViewById(R.id.text_track_artist)
        val trackDuration: TextView = itemView.findViewById(R.id.text_track_duration)
        val btnPlay: ImageButton = itemView.findViewById(R.id.btn_play_track)
        val btnAddToPlaylist: ImageButton = itemView.findViewById(R.id.btn_add_to_playlist)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TrackViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_music_track, parent, false)
        return TrackViewHolder(view)
    }

    override fun onBindViewHolder(holder: TrackViewHolder, position: Int) {
        val track = tracks[position]
        
        holder.trackTitle.text = track.title
        holder.trackArtist.text = track.artist
        holder.trackDuration.text = formatDuration(track.duration)
        
        holder.btnPlay.setOnClickListener {
            onTrackClick(track)
        }
        
        holder.itemView.setOnClickListener {
            onTrackClick(track)
        }
        
        holder.btnAddToPlaylist.setOnClickListener {
            // TODO: Show playlist selection dialog
        }
    }

    override fun getItemCount() = tracks.size
    
    fun updateTracks(newTracks: List<MusicTrack>) {
        tracks.clear()
        tracks.addAll(newTracks)
        notifyDataSetChanged()
    }
    
    private fun formatDuration(duration: Long): String {
        val seconds = (duration / 1000) % 60
        val minutes = (duration / (1000 * 60)) % 60
        val hours = (duration / (1000 * 60 * 60)) % 24
        
        return if (hours > 0) {
            String.format("%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%d:%02d", minutes, seconds)
        }
    }
}
