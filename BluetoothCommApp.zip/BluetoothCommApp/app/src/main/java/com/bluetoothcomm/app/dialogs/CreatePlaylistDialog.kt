package com.bluetoothcomm.app.dialogs

import android.app.Dialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.bluetoothcomm.app.R

class CreatePlaylistDialog(
    private val onPlaylistCreated: (name: String, description: String) -> Unit
) : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val view = layoutInflater.inflate(R.layout.dialog_create_playlist, null)
        
        val editPlaylistName = view.findViewById<EditText>(R.id.edit_playlist_name)
        val editDescription = view.findViewById<EditText>(R.id.edit_playlist_description)
        val btnCreate = view.findViewById<Button>(R.id.btn_create)
        val btnCancel = view.findViewById<Button>(R.id.btn_cancel)
        
        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Create Playlist")
            .setView(view)
            .create()
        
        btnCreate.setOnClickListener {
            val playlistName = editPlaylistName.text.toString().trim()
            val description = editDescription.text.toString().trim()
            
            if (playlistName.isNotEmpty()) {
                onPlaylistCreated(playlistName, description)
                dialog.dismiss()
            } else {
                editPlaylistName.error = "Playlist name is required"
            }
        }
        
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        
        return dialog
    }
}
