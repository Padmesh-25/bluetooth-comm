package com.bluetoothcomm.app.utils

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

class UserPreferences(context: Context) {
    
    companion object {
        private const val PREFS_NAME = "bluetooth_comm_prefs"
        
        // User Info Keys
        private const val KEY_USERNAME = "username"
        private const val KEY_MOBILE_NUMBER = "mobile_number"
        private const val KEY_DISPLAY_NAME = "display_name"
        
        // App Preferences Keys
        private const val KEY_VOICE_NOTIFICATIONS = "voice_notifications"
        private const val KEY_LOCATION_SHARING = "location_sharing"
        private const val KEY_AUTO_JOIN_LAST_CHANNEL = "auto_join_last_channel"
        private const val KEY_KEEP_SCREEN_ON = "keep_screen_on"
        private const val KEY_LAST_CHANNEL = "last_channel"
        
        // Audio Settings Keys
        private const val KEY_MIC_SENSITIVITY = "mic_sensitivity"
        private const val KEY_SPEAKER_VOLUME = "speaker_volume"
        
        // Default Values
        private const val DEFAULT_MIC_SENSITIVITY = 50
        private const val DEFAULT_SPEAKER_VOLUME = 70
    }
    
    private val sharedPreferences: SharedPreferences = 
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    // User Info Methods
    fun getUsername(): String = sharedPreferences.getString(KEY_USERNAME, "") ?: ""
    
    fun setUsername(username: String) {
        sharedPreferences.edit().putString(KEY_USERNAME, username).apply()
    }
    
    fun getMobileNumber(): String = sharedPreferences.getString(KEY_MOBILE_NUMBER, "") ?: ""
    
    fun setMobileNumber(mobileNumber: String) {
        sharedPreferences.edit().putString(KEY_MOBILE_NUMBER, mobileNumber).apply()
    }
    
    fun getDisplayName(): String {
        val displayName = sharedPreferences.getString(KEY_DISPLAY_NAME, "") ?: ""
        return displayName.ifEmpty { getUsername() }
    }
    
    fun setDisplayName(displayName: String) {
        sharedPreferences.edit().putString(KEY_DISPLAY_NAME, displayName).apply()
    }
    
    // App Preferences Methods
    fun isVoiceNotificationsEnabled(): Boolean = 
        sharedPreferences.getBoolean(KEY_VOICE_NOTIFICATIONS, true)
    
    fun setVoiceNotificationsEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_VOICE_NOTIFICATIONS, enabled).apply()
    }
    
    fun isLocationSharingEnabled(): Boolean = 
        sharedPreferences.getBoolean(KEY_LOCATION_SHARING, true)
    
    fun setLocationSharingEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_LOCATION_SHARING, enabled).apply()
    }
    
    fun isAutoJoinLastChannelEnabled(): Boolean = 
        sharedPreferences.getBoolean(KEY_AUTO_JOIN_LAST_CHANNEL, false)
    
    fun setAutoJoinLastChannelEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_AUTO_JOIN_LAST_CHANNEL, enabled).apply()
    }
    
    fun isKeepScreenOnEnabled(): Boolean = 
        sharedPreferences.getBoolean(KEY_KEEP_SCREEN_ON, false)
    
    fun setKeepScreenOnEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_KEEP_SCREEN_ON, enabled).apply()
    }
    
    fun getLastChannel(): String = sharedPreferences.getString(KEY_LAST_CHANNEL, "") ?: ""
    
    fun setLastChannel(channelName: String) {
        sharedPreferences.edit().putString(KEY_LAST_CHANNEL, channelName).apply()
    }
    
    // Audio Settings Methods
    fun getMicSensitivity(): Int = 
        sharedPreferences.getInt(KEY_MIC_SENSITIVITY, DEFAULT_MIC_SENSITIVITY)
    
    fun setMicSensitivity(sensitivity: Int) {
        val clampedValue = sensitivity.coerceIn(0, 100)
        sharedPreferences.edit().putInt(KEY_MIC_SENSITIVITY, clampedValue).apply()
    }
    
    fun getSpeakerVolume(): Int = 
        sharedPreferences.getInt(KEY_SPEAKER_VOLUME, DEFAULT_SPEAKER_VOLUME)
    
    fun setSpeakerVolume(volume: Int) {
        val clampedValue = volume.coerceIn(0, 100)
        sharedPreferences.edit().putInt(KEY_SPEAKER_VOLUME, clampedValue).apply()
    }
    
    // Utility Methods
    fun getUserInfo(): UserInfo {
        return UserInfo(
            username = getUsername(),
            mobileNumber = getMobileNumber(),
            displayName = getDisplayName()
        )
    }
    
    fun exportSettings(): String {
        val settings = JSONObject().apply {
            put("username", getUsername())
            put("display_name", getDisplayName())
            put("voice_notifications", isVoiceNotificationsEnabled())
            put("location_sharing", isLocationSharingEnabled())
            put("auto_join_last_channel", isAutoJoinLastChannelEnabled())
            put("keep_screen_on", isKeepScreenOnEnabled())
            put("mic_sensitivity", getMicSensitivity())
            put("speaker_volume", getSpeakerVolume())
            put("app_version", "1.0")
            put("export_date", System.currentTimeMillis())
        }
        
        return "Bluetooth Comm App Settings:\n\n${settings.toString(2)}"
    }
    
    fun resetToDefaults() {
        sharedPreferences.edit().apply {
            putBoolean(KEY_VOICE_NOTIFICATIONS, true)
            putBoolean(KEY_LOCATION_SHARING, true)
            putBoolean(KEY_AUTO_JOIN_LAST_CHANNEL, false)
            putBoolean(KEY_KEEP_SCREEN_ON, false)
            putInt(KEY_MIC_SENSITIVITY, DEFAULT_MIC_SENSITIVITY)
            putInt(KEY_SPEAKER_VOLUME, DEFAULT_SPEAKER_VOLUME)
            remove(KEY_LAST_CHANNEL)
        }.apply()
    }
    
    fun clearAll() {
        sharedPreferences.edit().clear().apply()
    }
    
    // Helper method to get formatted user display
    fun getFormattedUserDisplay(): String {
        val username = getUsername()
        val displayName = getDisplayName()
        val mobile = getMobileNumber()
        
        return when {
            displayName.isNotEmpty() && displayName != username -> "$displayName ($username)"
            mobile.isNotEmpty() -> "$username - $mobile"
            else -> username
        }
    }
    
    data class UserInfo(
        val username: String,
        val mobileNumber: String,
        val displayName: String
    ) {
        fun getIdentifier(): String {
            return displayName.ifEmpty { username }
        }
        
        fun getFullDisplay(): String {
            return when {
                displayName.isNotEmpty() && displayName != username -> "$displayName ($username)"
                mobileNumber.isNotEmpty() -> "$username - $mobileNumber"
                else -> username
            }
        }
    }
}
