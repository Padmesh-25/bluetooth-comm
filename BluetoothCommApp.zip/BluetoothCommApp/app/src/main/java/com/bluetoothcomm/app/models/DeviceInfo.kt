package com.bluetoothcomm.app.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class DeviceInfo(
    val deviceId: String,
    val deviceName: String,
    val bluetoothAddress: String,
    val username: String = "",
    val displayName: String = "",
    val mobileNumber: String = "",
    val isConnected: Boolean = false,
    val lastSeen: Long = System.currentTimeMillis(),
    val batteryLevel: Int = -1,
    val signalStrength: Int = -1,
    val currentChannel: String? = null,
    val location: LocationData? = null
) {
    fun getDisplayIdentifier(): String {
        return when {
            displayName.isNotEmpty() && displayName != username -> "$displayName ($username)"
            username.isNotEmpty() -> username
            else -> deviceName
        }
    }
    
    fun getShortIdentifier(): String {
        return when {
            displayName.isNotEmpty() -> displayName
            username.isNotEmpty() -> username
            else -> deviceName
        }
    }
    
    fun getFullIdentifier(): String {
        val identifier = getDisplayIdentifier()
        return if (mobileNumber.isNotEmpty()) {
            "$identifier - $mobileNumber"
        } else {
            identifier
        }
    }
} : Parcelable
