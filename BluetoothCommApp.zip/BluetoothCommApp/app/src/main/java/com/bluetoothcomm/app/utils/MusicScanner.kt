package com.bluetoothcomm.app.utils

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import com.bluetoothcomm.app.models.MusicTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*

class MusicScanner(
    private val context: Context,
    private val onScanComplete: (List<MusicTrack>) -> Unit
) {
    
    companion object {
        private const val TAG = "MusicScanner"
    }
    
    fun scanForMusic() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val tracks = scanMusicFiles()
                withContext(Dispatchers.Main) {
                    onScanComplete(tracks)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error scanning music files", e)
                withContext(Dispatchers.Main) {
                    onScanComplete(emptyList())
                }
            }
        }
    }
    
    private fun scanMusicFiles(): List<MusicTrack> {
        val tracks = mutableListOf<MusicTrack>()
        
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED
        )
        
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} = 1"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"
        
        val cursor: Cursor? = context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            null,
            sortOrder
        )
        
        cursor?.use { c ->
            val idColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val dateColumn = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            
            while (c.moveToNext()) {
                val id = c.getLong(idColumn)
                val title = c.getString(titleColumn) ?: "Unknown Title"
                val artist = c.getString(artistColumn) ?: "Unknown Artist"
                val album = c.getString(albumColumn) ?: "Unknown Album"
                val duration = c.getLong(durationColumn)
                val filePath = c.getString(dataColumn) ?: ""
                val dateAdded = c.getLong(dateColumn) * 1000 // Convert to milliseconds
                
                if (filePath.isNotEmpty()) {
                    val track = MusicTrack(
                        id = id.toString(),
                        title = title,
                        artist = artist,
                        album = album,
                        duration = duration,
                        filePath = filePath,
                        dateAdded = dateAdded
                    )
                    tracks.add(track)
                }
            }
        }
        
        Log.d(TAG, "Found ${tracks.size} music tracks")
        return tracks
    }
    
    fun createTrackFromUri(uri: Uri): MusicTrack? {
        return try {
            val projection = arrayOf(
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION
            )
            
            val cursor = context.contentResolver.query(uri, projection, null, null, null)
            cursor?.use { c ->
                if (c.moveToFirst()) {
                    val titleIndex = c.getColumnIndex(MediaStore.Audio.Media.TITLE)
                    val artistIndex = c.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                    val albumIndex = c.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                    val durationIndex = c.getColumnIndex(MediaStore.Audio.Media.DURATION)
                    
                    val title = if (titleIndex >= 0) c.getString(titleIndex) else "Unknown Title"
                    val artist = if (artistIndex >= 0) c.getString(artistIndex) else "Unknown Artist"
                    val album = if (albumIndex >= 0) c.getString(albumIndex) else "Unknown Album"
                    val duration = if (durationIndex >= 0) c.getLong(durationIndex) else 0L
                    
                    MusicTrack(
                        id = UUID.randomUUID().toString(),
                        title = title ?: "Unknown Title",
                        artist = artist ?: "Unknown Artist",
                        album = album ?: "Unknown Album",
                        duration = duration,
                        filePath = uri.toString()
                    )
                } else null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error creating track from URI", e)
            null
        }
    }
    
    fun getAlbumArt(albumId: String): String? {
        return try {
            val uri = Uri.parse("content://media/external/audio/albumart")
            Uri.withAppendedPath(uri, albumId).toString()
        } catch (e: Exception) {
            Log.e(TAG, "Error getting album art", e)
            null
        }
    }
}
