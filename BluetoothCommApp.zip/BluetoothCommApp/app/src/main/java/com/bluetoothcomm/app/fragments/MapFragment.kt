package com.bluetoothcomm.app.fragments

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.fragment.Fragment
import androidx.preference.PreferenceManager
import com.bluetoothcomm.app.bluetooth.BluetoothService
import com.bluetoothcomm.app.databinding.FragmentMapBinding
import com.bluetoothcomm.app.models.DeviceInfo
import com.bluetoothcomm.app.models.LocationData
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.infowindow.InfoWindow
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bluetoothcomm.app.adapters.SearchResultsAdapter
import com.bluetoothcomm.app.models.SearchResult

class MapFragment : Fragment(), LocationListener {
    
    private var _binding: FragmentMapBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var mapView: MapView
    private var bluetoothService: BluetoothService? = null
    private var isBound = false
    
    private lateinit var locationManager: LocationManager
    private var myLocationOverlay: MyLocationNewOverlay? = null
    private val deviceMarkers = mutableMapOf<String, Marker>()
    private var routePolyline: Polyline? = null
    private var destinationMarker: Marker? = null
    
    private var currentLocation: Location? = null
    private lateinit var searchResultsAdapter: SearchResultsAdapter
    private val searchResults = mutableListOf<SearchResult>()
    private var isNavigating = false
    
    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as BluetoothService.LocalBinder
            bluetoothService = binder.getService()
            isBound = true
            setupObservers()
        }
        
        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMapBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupMap()
        setupLocationServices()
        bindBluetoothService()
        setupClickListeners()
        setupSearchFunctionality()
    }
    
    private fun setupMap() {
        // Initialize osmdroid configuration
        Configuration.getInstance().load(
            requireContext(),
            PreferenceManager.getDefaultSharedPreferences(requireContext())
        )
        
        mapView = binding.mapView
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        
        // Set default zoom and center
        mapView.controller.setZoom(15.0)
        mapView.controller.setCenter(GeoPoint(37.7749, -122.4194)) // Default to San Francisco
        
        // Add my location overlay
        myLocationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(requireContext()), mapView)
        myLocationOverlay?.enableMyLocation()
        mapView.overlays.add(myLocationOverlay)
        
        // Enable offline tile caching
        mapView.setUseDataConnection(false) // This enables offline mode
    }
    
    private fun setupLocationServices() {
        locationManager = requireContext().getSystemService(Context.LOCATION_SERVICE) as LocationManager
        
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            // Request location updates
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                5000L, // 5 seconds
                10f,   // 10 meters
                this
            )
            
            // Get last known location
            val lastLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            lastLocation?.let { onLocationChanged(it) }
        }
    }
    
    private fun bindBluetoothService() {
        val intent = Intent(context, BluetoothService::class.java)
        context?.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }
    
    private fun setupObservers() {
        bluetoothService?.connectedDevicesList?.observe(viewLifecycleOwner) { devices ->
            updateDeviceMarkers(devices)
        }
        
        bluetoothService?.locationUpdates?.observe(viewLifecycleOwner) { locationData ->
            updateDeviceLocation(locationData)
        }
    }
    
    private fun setupClickListeners() {
        binding.btnCenterOnMe.setOnClickListener {
            centerMapOnCurrentLocation()
        }
        
        binding.btnToggleOffline.setOnClickListener {
            toggleOfflineMode()
        }
        
        binding.btnShareLocation.setOnClickListener {
            shareCurrentLocation()
        }
        
        binding.btnClearRoute.setOnClickListener {
            clearRoute()
        }
        
        binding.fabMapOptions.setOnClickListener {
            toggleSearchPanel()
        }
    }
    
    override fun onLocationChanged(location: Location) {
        currentLocation = location
        val geoPoint = GeoPoint(location.latitude, location.longitude)
        
        // Update map center if this is the first location
        if (mapView.mapCenter.latitude == 37.7749) {
            mapView.controller.setCenter(geoPoint)
        }
        
        // Share location with connected devices
        shareLocationWithDevices(location)
        
        binding.textLocationInfo.text = 
            "Lat: ${String.format("%.6f", location.latitude)}, " +
            "Lng: ${String.format("%.6f", location.longitude)}\n" +
            "Accuracy: ${location.accuracy}m"
    }
    
    private fun shareLocationWithDevices(location: Location) {
        val locationData = LocationData(
            deviceId = "current_device", // Replace with actual device ID
            deviceName = "My Device",
            latitude = location.latitude,
            longitude = location.longitude,
            accuracy = location.accuracy
        )
        
        bluetoothService?.sendMessage(locationData)
    }
    
    private fun updateDeviceMarkers(devices: List<DeviceInfo>) {
        // Remove markers for disconnected devices
        val currentDeviceIds = devices.map { it.deviceId }.toSet()
        val markersToRemove = deviceMarkers.keys.filter { it !in currentDeviceIds }
        
        markersToRemove.forEach { deviceId ->
            deviceMarkers[deviceId]?.let { marker ->
                mapView.overlays.remove(marker)
            }
            deviceMarkers.remove(deviceId)
        }
        
        // Add or update markers for connected devices
        devices.forEach { device ->
            if (device.latitude != 0.0 && device.longitude != 0.0) {
                updateDeviceMarker(device)
            }
        }
        
        mapView.invalidate()
        updateDeviceCount(devices.size)
    }
    
    private fun updateDeviceMarker(device: DeviceInfo) {
        val geoPoint = GeoPoint(device.latitude, device.longitude)
        
        val marker = deviceMarkers[device.deviceId] ?: run {
            val newMarker = Marker(mapView)
            newMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            mapView.overlays.add(newMarker)
            deviceMarkers[device.deviceId] = newMarker
            newMarker
        }
        
        marker.position = geoPoint
        marker.title = device.deviceName
        marker.snippet = "Channel: ${device.currentChannel ?: "None"}\nLast seen: ${formatTime(device.lastSeen)}"
        
        // Set different colors based on channel or status
        marker.icon = when {
            device.currentChannel != null -> resources.getDrawable(android.R.drawable.ic_menu_mylocation, null)
            else -> resources.getDrawable(android.R.drawable.ic_menu_compass, null)
        }
    }
    
    private fun updateDeviceLocation(locationData: LocationData) {
        // This will be handled by the device list update, but we can add specific logic here if needed
        Toast.makeText(
            context,
            "${locationData.deviceName} location updated",
            Toast.LENGTH_SHORT
        ).show()
    }
    
    private fun centerMapOnCurrentLocation() {
        currentLocation?.let { location ->
            val geoPoint = GeoPoint(location.latitude, location.longitude)
            mapView.controller.animateTo(geoPoint)
            mapView.controller.setZoom(18.0)
        } ?: run {
            Toast.makeText(context, "Current location not available", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun toggleOfflineMode() {
        val isOffline = !mapView.useDataConnection
        mapView.setUseDataConnection(isOffline)
        
        binding.btnToggleOffline.text = if (isOffline) "Go Offline" else "Go Online"
        
        Toast.makeText(
            context,
            if (isOffline) "Online mode enabled" else "Offline mode enabled",
            Toast.LENGTH_SHORT
        ).show()
    }
    
    private fun shareCurrentLocation() {
        currentLocation?.let { location ->
            shareLocationWithDevices(location)
            Toast.makeText(context, "Location shared with connected devices", Toast.LENGTH_SHORT).show()
        } ?: run {
            Toast.makeText(context, "Current location not available", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun updateDeviceCount(count: Int) {
        binding.textDeviceCount.text = "Devices on Map: $count"
    }
    
    private fun setupSearchFunctionality() {
        // Setup search results RecyclerView
        searchResultsAdapter = SearchResultsAdapter(searchResults) { searchResult ->
            selectDestination(searchResult)
        }
        
        binding.recyclerViewSearchResults.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = searchResultsAdapter
        }
        
        // Setup search view
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let { searchLocation(it) }
                return true
            }
            
            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText.isNullOrEmpty()) {
                    searchResults.clear()
                    searchResultsAdapter.notifyDataSetChanged()
                }
                return true
            }
        })
    }
    
    private fun searchLocation(query: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val encodedQuery = URLEncoder.encode(query, "UTF-8")
                val url = "https://nominatim.openstreetmap.org/search?format=json&q=$encodedQuery&limit=5"
                
                val response = URL(url).readText()
                val jsonArray = JSONArray(response)
                
                val results = mutableListOf<SearchResult>()
                for (i in 0 until jsonArray.length()) {
                    val item = jsonArray.getJSONObject(i)
                    val result = SearchResult(
                        displayName = item.getString("display_name"),
                        latitude = item.getDouble("lat"),
                        longitude = item.getDouble("lon"),
                        type = item.optString("type", "location")
                    )
                    results.add(result)
                }
                
                withContext(Dispatchers.Main) {
                    searchResults.clear()
                    searchResults.addAll(results)
                    searchResultsAdapter.notifyDataSetChanged()
                    
                    if (results.isNotEmpty()) {
                        binding.layoutSearchResults.visibility = View.VISIBLE
                    }
                }
                
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Search failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun selectDestination(searchResult: SearchResult) {
        val destinationPoint = GeoPoint(searchResult.latitude, searchResult.longitude)
        
        // Add destination marker
        destinationMarker?.let { mapView.overlays.remove(it) }
        destinationMarker = Marker(mapView).apply {
            position = destinationPoint
            title = "Destination"
            snippet = searchResult.displayName
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            icon = resources.getDrawable(android.R.drawable.ic_menu_mylocation, null)
        }
        mapView.overlays.add(destinationMarker)
        
        // Center map on destination
        mapView.controller.animateTo(destinationPoint)
        mapView.controller.setZoom(16.0)
        
        // Hide search results
        binding.layoutSearchResults.visibility = View.GONE
        
        // Calculate route if we have current location
        currentLocation?.let { location ->
            calculateRoute(
                GeoPoint(location.latitude, location.longitude),
                destinationPoint
            )
        }
        
        mapView.invalidate()
    }
    
    private fun calculateRoute(start: GeoPoint, end: GeoPoint) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Using OSRM (Open Source Routing Machine) - free routing service
                val url = "https://router.project-osrm.org/route/v1/driving/" +
                        "${start.longitude},${start.latitude};${end.longitude},${end.latitude}" +
                        "?overview=full&geometries=geojson&steps=true"
                
                val response = URL(url).readText()
                val jsonResponse = JSONObject(response)
                
                if (jsonResponse.getString("code") == "Ok") {
                    val routes = jsonResponse.getJSONArray("routes")
                    if (routes.length() > 0) {
                        val route = routes.getJSONObject(0)
                        val geometry = route.getJSONObject("geometry")
                        val coordinates = geometry.getJSONArray("coordinates")
                        
                        val routePoints = mutableListOf<GeoPoint>()
                        for (i in 0 until coordinates.length()) {
                            val coord = coordinates.getJSONArray(i)
                            routePoints.add(GeoPoint(coord.getDouble(1), coord.getDouble(0)))
                        }
                        
                        // Get turn-by-turn instructions
                        val legs = route.getJSONArray("legs")
                        val instructions = mutableListOf<String>()
                        for (i in 0 until legs.length()) {
                            val leg = legs.getJSONObject(i)
                            val steps = leg.getJSONArray("steps")
                            for (j in 0 until steps.length()) {
                                val step = steps.getJSONObject(j)
                                val maneuver = step.getJSONObject("maneuver")
                                val instruction = maneuver.optString("instruction", "Continue")
                                instructions.add(instruction)
                            }
                        }
                        
                        withContext(Dispatchers.Main) {
                            displayRoute(routePoints, instructions)
                        }
                    }
                }
                
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Route calculation failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun displayRoute(routePoints: List<GeoPoint>, instructions: List<String>) {
        // Remove existing route
        routePolyline?.let { mapView.overlays.remove(it) }
        
        // Create new route polyline
        routePolyline = Polyline().apply {
            setPoints(routePoints)
            color = resources.getColor(R.color.route_color, null)
            width = 8.0f
        }
        
        mapView.overlays.add(routePolyline)
        
        // Show route controls
        binding.btnClearRoute.visibility = View.VISIBLE
        isNavigating = true
        
        // Show route info
        val distance = routePolyline?.distance ?: 0.0
        val distanceKm = (distance / 1000).toInt()
        binding.textRouteInfo.text = "Route: ${distanceKm}km"
        binding.textRouteInfo.visibility = View.VISIBLE
        
        // Fit route in view
        val boundingBox = org.osmdroid.util.BoundingBox.fromGeoPoints(routePoints)
        mapView.zoomToBoundingBox(boundingBox, true, 100)
        
        mapView.invalidate()
        
        Toast.makeText(context, "Route calculated! ${instructions.size} turns", Toast.LENGTH_SHORT).show()
    }
    
    private fun clearRoute() {
        routePolyline?.let { mapView.overlays.remove(it) }
        destinationMarker?.let { mapView.overlays.remove(it) }
        
        routePolyline = null
        destinationMarker = null
        isNavigating = false
        
        binding.btnClearRoute.visibility = View.GONE
        binding.textRouteInfo.visibility = View.GONE
        
        mapView.invalidate()
        Toast.makeText(context, "Route cleared", Toast.LENGTH_SHORT).show()
    }
    
    private fun toggleSearchPanel() {
        val isVisible = binding.layoutSearchPanel.visibility == View.VISIBLE
        binding.layoutSearchPanel.visibility = if (isVisible) View.GONE else View.VISIBLE
        
        if (!isVisible) {
            binding.searchView.requestFocus()
        }
    }
    
    private fun formatTime(timestamp: Long): String {
        val diff = System.currentTimeMillis() - timestamp
        return when {
            diff < 60000 -> "Just now"
            diff < 3600000 -> "${diff / 60000}m ago"
            diff < 86400000 -> "${diff / 3600000}h ago"
            else -> "${diff / 86400000}d ago"
        }
    }
    
    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }
    
    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            locationManager.removeUpdates(this)
        }
        
        if (isBound) {
            context?.unbindService(serviceConnection)
            isBound = false
        }
        
        _binding = null
    }
    
    // LocationListener methods
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}
