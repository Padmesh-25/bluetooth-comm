package com.bluetoothcomm.app.fragments

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.os.IBinder
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bluetoothcomm.app.R
import com.bluetoothcomm.app.adapters.ChannelAdapter
import com.bluetoothcomm.app.adapters.ConnectedDevicesAdapter
import com.bluetoothcomm.app.bluetooth.BluetoothService
import com.bluetoothcomm.app.databinding.FragmentVoiceChannelBinding
import com.bluetoothcomm.app.dialogs.CreateChannelDialog
import com.bluetoothcomm.app.models.DeviceInfo
import com.bluetoothcomm.app.models.VoiceChannel
import com.bluetoothcomm.app.models.VoiceMessage
import com.bluetoothcomm.app.voice.VoiceService
import java.util.*
import kotlin.collections.ArrayList

class VoiceChannelFragment : Fragment() {
    
    private var _binding: FragmentVoiceChannelBinding? = null
    private val binding get() = _binding!!
    
    private var bluetoothService: BluetoothService? = null
    private var voiceService: VoiceService? = null
    private var isBound = false
    
    private lateinit var channelAdapter: ChannelAdapter
    private lateinit var devicesAdapter: ConnectedDevicesAdapter
    
    private val availableChannels = mutableListOf<VoiceChannel>()
    private var currentChannel: VoiceChannel? = null
    private var isRecording = false
    private var isMicOpen = false // Toggle state for click-to-talk
    
    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as BluetoothService.LocalBinder
            bluetoothService = binder.getService()
            isBound = true
            setupObservers()
        }
        
        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
        }
    }
    
    private val voiceServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as VoiceService.LocalBinder
            voiceService = binder.getService()
        }
        
        override fun onServiceDisconnected(arg0: ComponentName) {
            voiceService = null
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentVoiceChannelBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupRecyclerViews()
        setupClickListeners()
        bindServices()
        
        // Add default channels
        addDefaultChannels()
    }
    
    private fun setupRecyclerViews() {
        // Channels RecyclerView
        channelAdapter = ChannelAdapter(availableChannels) { channel ->
            joinChannel(channel)
        }
        binding.recyclerViewChannels.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = channelAdapter
        }
        
        // Connected Devices RecyclerView
        devicesAdapter = ConnectedDevicesAdapter(ArrayList()) { device ->
            // Handle device click if needed
        }
        binding.recyclerViewDevices.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = devicesAdapter
        }
    }
    
    private fun setupClickListeners() {
        binding.btnCreateChannel.setOnClickListener {
            showCreateChannelDialog()
        }
        
        binding.btnLeaveChannel.setOnClickListener {
            leaveCurrentChannel()
        }
        
        binding.btnMuteAll.setOnClickListener {
            toggleMuteAll()
        }
        
        binding.btnStartDiscovery.setOnClickListener {
            bluetoothService?.startDiscovery()
            Toast.makeText(context, "Searching for nearby devices...", Toast.LENGTH_SHORT).show()
        }
        
        // Click-to-talk functionality (toggle)
        binding.btnClickToTalk.setOnClickListener {
            toggleMicrophone()
        }
    }
    
    private fun bindServices() {
        val bluetoothIntent = Intent(context, BluetoothService::class.java)
        context?.bindService(bluetoothIntent, serviceConnection, Context.BIND_AUTO_CREATE)
        
        val voiceIntent = Intent(context, VoiceService::class.java)
        context?.bindService(voiceIntent, voiceServiceConnection, Context.BIND_AUTO_CREATE)
        context?.startService(voiceIntent)
    }
    
    private fun setupObservers() {
        bluetoothService?.connectedDevicesList?.observe(viewLifecycleOwner) { devices ->
            devicesAdapter.updateDevices(devices)
            updateDeviceCount(devices.size)
        }
        
        bluetoothService?.receivedMessages?.observe(viewLifecycleOwner) { message ->
            handleReceivedVoiceMessage(message)
        }
    }
    
    private fun addDefaultChannels() {
        val defaultChannels = listOf(
            VoiceChannel("general", "General", "system"),
            VoiceChannel("emergency", "Emergency", "system"),
            VoiceChannel("group1", "Group 1", "system")
        )
        
        availableChannels.addAll(defaultChannels)
        channelAdapter.notifyDataSetChanged()
    }
    
    private fun showCreateChannelDialog() {
        val dialog = CreateChannelDialog { channelName, isPrivate, password ->
            createNewChannel(channelName, isPrivate, password)
        }
        dialog.show(parentFragmentManager, "CreateChannelDialog")
    }
    
    private fun createNewChannel(name: String, isPrivate: Boolean, password: String?) {
        val channelId = UUID.randomUUID().toString()
        val newChannel = VoiceChannel(
            channelId = channelId,
            channelName = name,
            createdBy = "current_user", // Replace with actual user ID
            isPrivate = isPrivate,
            password = password
        )
        
        availableChannels.add(newChannel)
        channelAdapter.notifyItemInserted(availableChannels.size - 1)
        
        // Broadcast new channel to connected devices
        bluetoothService?.sendMessage(mapOf(
            "type" to "channel_created",
            "channel" to newChannel
        ))
    }
    
    private fun joinChannel(channel: VoiceChannel) {
        currentChannel?.let { leaveCurrentChannel() }
        
        currentChannel = channel
        channel.currentParticipants.add("current_user") // Replace with actual user ID
        
        binding.textCurrentChannel.text = "Current Channel: ${channel.channelName}"
        binding.btnLeaveChannel.visibility = View.VISIBLE
        binding.btnClickToTalk.isEnabled = true
        binding.btnMuteAll.visibility = View.VISIBLE
        
        // Reset mic state when joining new channel
        if (isMicOpen) {
            stopContinuousRecording()
        }
        
        // Update UI for new channel
        binding.btnClickToTalk.text = "🔇 MUTED"
        binding.textMicStatus.text = "⚪ Microphone Muted - Click to Transmit"
        binding.textMicStatus.visibility = View.VISIBLE
        
        // Notify other devices about joining
        bluetoothService?.sendMessage(mapOf(
            "type" to BluetoothService.MESSAGE_TYPE_CHANNEL_JOIN,
            "channelId" to channel.channelId,
            "userId" to "current_user",
            "userName" to "Current User"
        ))
        
        Toast.makeText(context, "Joined channel: ${channel.channelName}", Toast.LENGTH_SHORT).show()
    }
    
    private fun leaveCurrentChannel() {
        currentChannel?.let { channel ->
            channel.currentParticipants.remove("current_user")
            
            // Notify other devices about leaving
            bluetoothService?.sendMessage(mapOf(
                "type" to BluetoothService.MESSAGE_TYPE_CHANNEL_LEAVE,
                "channelId" to channel.channelId,
                "userId" to "current_user"
            ))
            
            currentChannel = null
            binding.textCurrentChannel.text = "No channel selected"
            binding.btnLeaveChannel.visibility = View.GONE
            binding.btnClickToTalk.isEnabled = false
            binding.btnMuteAll.visibility = View.GONE
            binding.textMicStatus.visibility = View.GONE
            
            // Stop recording if active
            if (isMicOpen) {
                stopContinuousRecording()
            }
            
            Toast.makeText(context, "Left channel: ${channel.channelName}", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun toggleMicrophone() {
        if (currentChannel == null) {
            Toast.makeText(context, "Please join a channel first", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(context, "Audio recording permission required", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (!isMicOpen) {
            startContinuousRecording()
        } else {
            stopContinuousRecording()
        }
    }
    
    private fun startContinuousRecording() {
        isMicOpen = true
        isRecording = true
        
        // Update UI to show mic is open
        binding.btnClickToTalk.text = "🎤 ON AIR"
        binding.btnClickToTalk.setBackgroundColor(resources.getColor(R.color.recording_color, null))
        binding.textMicStatus.text = "🔴 Microphone Active - Click to Mute"
        binding.textMicStatus.visibility = View.VISIBLE
        
        // Start continuous recording with periodic transmission
        voiceService?.startContinuousRecording { audioData ->
            sendVoiceMessage(audioData)
        }
        
        Toast.makeText(context, "Microphone ON - You are transmitting", Toast.LENGTH_SHORT).show()
    }
    
    private fun stopContinuousRecording() {
        isMicOpen = false
        isRecording = false
        
        // Update UI to show mic is muted
        binding.btnClickToTalk.text = "🔇 MUTED"
        binding.btnClickToTalk.setBackgroundColor(resources.getColor(R.color.primary_color, null))
        binding.textMicStatus.text = "⚪ Microphone Muted - Click to Transmit"
        
        voiceService?.stopRecording()
        
        Toast.makeText(context, "Microphone OFF - You are muted", Toast.LENGTH_SHORT).show()
    }
    
    private fun sendVoiceMessage(audioData: ByteArray) {
        currentChannel?.let { channel ->
            val message = VoiceMessage(
                messageId = UUID.randomUUID().toString(),
                senderId = "current_user",
                senderName = "Current User",
                channelId = channel.channelId,
                audioData = audioData,
                duration = audioData.size / 16000L // Approximate duration
            )
            
            bluetoothService?.sendMessage(message, channel.channelId)
        }
    }
    
    private fun handleReceivedVoiceMessage(message: VoiceMessage) {
        if (message.channelId == currentChannel?.channelId) {
            // Play the received audio
            voiceService?.playAudio(message.audioData)
            
            // Show notification
            Toast.makeText(
                context,
                "Voice message from ${message.senderName}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
    
    private fun updateDeviceCount(count: Int) {
        binding.textDeviceCount.text = "Connected Devices: $count"
    }
    
    private fun toggleMuteAll() {
        // Toggle mute for all incoming audio from other devices
        voiceService?.let { service ->
            val currentVolume = if (service.isMuted()) 1.0f else 0.0f
            service.setVolume(currentVolume)
            
            val statusText = if (currentVolume == 0.0f) {
                "🔇 All audio muted"
            } else {
                "🔊 Audio enabled"
            }
            
            binding.btnMuteAll.text = if (currentVolume == 0.0f) "Unmute All" else "Mute All"
            Toast.makeText(context, statusText, Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        if (isBound) {
            context?.unbindService(serviceConnection)
            isBound = false
        }
        context?.unbindService(voiceServiceConnection)
        _binding = null
    }
}
