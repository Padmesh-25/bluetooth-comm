package com.bluetoothcomm.app.fragments

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bluetoothcomm.app.R
import com.bluetoothcomm.app.adapters.MusicTrackAdapter
import com.bluetoothcomm.app.adapters.PlaylistAdapter
import com.bluetoothcomm.app.databinding.FragmentMusicPlayerBinding
import com.bluetoothcomm.app.dialogs.CreatePlaylistDialog
import com.bluetoothcomm.app.models.MusicTrack
import com.bluetoothcomm.app.models.Playlist
import com.bluetoothcomm.app.music.MusicService
import com.bluetoothcomm.app.utils.MusicScanner
import java.util.*

class MusicPlayerFragment : Fragment() {
    
    private var _binding: FragmentMusicPlayerBinding? = null
    private val binding get() = _binding!!
    
    private var musicService: MusicService? = null
    private var isBound = false
    
    private lateinit var trackAdapter: MusicTrackAdapter
    private lateinit var playlistAdapter: PlaylistAdapter
    private lateinit var musicScanner: MusicScanner
    
    private val allTracks = mutableListOf<MusicTrack>()
    private val playlists = mutableListOf<Playlist>()
    private var currentPlaylist: Playlist? = null
    private var currentTrack: MusicTrack? = null
    private var isPlaying = false
    
    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as MusicService.LocalBinder
            musicService = binder.getService()
            isBound = true
            setupMusicServiceObservers()
        }
        
        override fun onServiceDisconnected(arg0: ComponentName) {
            isBound = false
        }
    }
    
    private val musicPickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            addTracksFromUris(uris)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMusicPlayerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupRecyclerViews()
        setupClickListeners()
        bindMusicService()
        initializeMusicScanner()
        scanForMusic()
    }
    
    private fun setupRecyclerViews() {
        // Tracks RecyclerView
        trackAdapter = MusicTrackAdapter(allTracks) { track ->
            playTrack(track)
        }
        binding.recyclerViewTracks.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = trackAdapter
        }
        
        // Playlists RecyclerView
        playlistAdapter = PlaylistAdapter(playlists,
            onPlaylistClick = { playlist ->
                selectPlaylist(playlist)
            },
            onShareClick = { playlist ->
                sharePlaylist(playlist)
            }
        )
        binding.recyclerViewPlaylists.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = playlistAdapter
        }
    }
    
    private fun setupClickListeners() {
        binding.btnPlayPause.setOnClickListener {
            togglePlayPause()
        }
        
        binding.btnPrevious.setOnClickListener {
            playPreviousTrack()
        }
        
        binding.btnNext.setOnClickListener {
            playNextTrack()
        }
        
        binding.btnAddMusic.setOnClickListener {
            musicPickerLauncher.launch("audio/*")
        }
        
        binding.btnCreatePlaylist.setOnClickListener {
            showCreatePlaylistDialog()
        }
        
        binding.btnScanMusic.setOnClickListener {
            scanForMusic()
        }
        
        binding.tabTracks.setOnClickListener {
            showTracksView()
        }
        
        binding.tabPlaylists.setOnClickListener {
            showPlaylistsView()
        }
        
        binding.seekBar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    musicService?.seekTo(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
    }
    
    private fun bindMusicService() {
        val intent = Intent(context, MusicService::class.java)
        context?.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        context?.startService(intent)
    }
    
    private fun initializeMusicScanner() {
        musicScanner = MusicScanner(requireContext()) { tracks ->
            allTracks.clear()
            allTracks.addAll(tracks)
            trackAdapter.notifyDataSetChanged()
            updateTrackCount()
        }
    }
    
    private fun setupMusicServiceObservers() {
        musicService?.let { service ->
            service.currentTrack.observe(viewLifecycleOwner) { track ->
                currentTrack = track
                updateNowPlaying(track)
            }
            
            service.isPlaying.observe(viewLifecycleOwner) { playing ->
                isPlaying = playing
                updatePlayPauseButton(playing)
            }
            
            service.currentPosition.observe(viewLifecycleOwner) { position ->
                updateSeekBar(position)
            }
            
            service.duration.observe(viewLifecycleOwner) { duration ->
                binding.seekBar.max = duration
                binding.textDuration.text = formatTime(duration)
            }
        }
    }
    
    private fun scanForMusic() {
        binding.progressBar.visibility = View.VISIBLE
        musicScanner.scanForMusic()
    }
    
    private fun addTracksFromUris(uris: List<Uri>) {
        uris.forEach { uri ->
            val track = musicScanner.createTrackFromUri(uri)
            track?.let {
                allTracks.add(it)
                trackAdapter.notifyItemInserted(allTracks.size - 1)
            }
        }
        updateTrackCount()
        Toast.makeText(context, "Added ${uris.size} tracks", Toast.LENGTH_SHORT).show()
    }
    
    private fun playTrack(track: MusicTrack) {
        musicService?.playTrack(track)
        currentTrack = track
    }
    
    private fun togglePlayPause() {
        if (isPlaying) {
            musicService?.pause()
        } else {
            if (currentTrack != null) {
                musicService?.resume()
            } else if (allTracks.isNotEmpty()) {
                playTrack(allTracks[0])
            }
        }
    }
    
    private fun playPreviousTrack() {
        currentTrack?.let { current ->
            val currentIndex = allTracks.indexOf(current)
            if (currentIndex > 0) {
                playTrack(allTracks[currentIndex - 1])
            } else if (allTracks.isNotEmpty()) {
                playTrack(allTracks.last())
            }
        }
    }
    
    private fun playNextTrack() {
        currentTrack?.let { current ->
            val currentIndex = allTracks.indexOf(current)
            if (currentIndex < allTracks.size - 1) {
                playTrack(allTracks[currentIndex + 1])
            } else if (allTracks.isNotEmpty()) {
                playTrack(allTracks.first())
            }
        }
    }
    
    private fun showCreatePlaylistDialog() {
        val dialog = CreatePlaylistDialog { name, description ->
            createPlaylist(name, description)
        }
        dialog.show(parentFragmentManager, "CreatePlaylistDialog")
    }
    
    private fun createPlaylist(name: String, description: String) {
        val playlist = Playlist(
            id = UUID.randomUUID().toString(),
            name = name,
            description = description
        )
        
        playlists.add(playlist)
        playlistAdapter.notifyItemInserted(playlists.size - 1)
        
        Toast.makeText(context, "Playlist '$name' created", Toast.LENGTH_SHORT).show()
    }
    
    private fun selectPlaylist(playlist: Playlist) {
        currentPlaylist = playlist
        binding.textCurrentPlaylist.text = "Playlist: ${playlist.name}"
        
        // Show tracks in this playlist
        trackAdapter.updateTracks(playlist.tracks)
        showTracksView()
    }
    
    private fun sharePlaylist(playlist: Playlist) {
        val shareText = buildString {
            appendLine("🎵 Check out my playlist: ${playlist.name}")
            if (playlist.description.isNotEmpty()) {
                appendLine("📝 ${playlist.description}")
            }
            appendLine()
            appendLine("Tracks:")
            playlist.tracks.forEachIndexed { index, track ->
                appendLine("${index + 1}. ${track.title} - ${track.artist}")
            }
            appendLine()
            appendLine("Shared from Bluetooth Comm App")
        }
        
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
            putExtra(Intent.EXTRA_SUBJECT, "Playlist: ${playlist.name}")
        }
        
        val chooserIntent = Intent.createChooser(shareIntent, "Share playlist via...")
        startActivity(chooserIntent)
    }
    
    private fun showTracksView() {
        binding.recyclerViewTracks.visibility = View.VISIBLE
        binding.recyclerViewPlaylists.visibility = View.GONE
        binding.tabTracks.setBackgroundColor(resources.getColor(R.color.tab_selected, null))
        binding.tabPlaylists.setBackgroundColor(resources.getColor(R.color.tab_unselected, null))
    }
    
    private fun showPlaylistsView() {
        binding.recyclerViewTracks.visibility = View.GONE
        binding.recyclerViewPlaylists.visibility = View.VISIBLE
        binding.tabTracks.setBackgroundColor(resources.getColor(R.color.tab_unselected, null))
        binding.tabPlaylists.setBackgroundColor(resources.getColor(R.color.tab_selected, null))
    }
    
    private fun updateNowPlaying(track: MusicTrack?) {
        if (track != null) {
            binding.textTrackTitle.text = track.title
            binding.textTrackArtist.text = track.artist
            binding.layoutNowPlaying.visibility = View.VISIBLE
        } else {
            binding.layoutNowPlaying.visibility = View.GONE
        }
    }
    
    private fun updatePlayPauseButton(playing: Boolean) {
        binding.btnPlayPause.setImageResource(
            if (playing) android.R.drawable.ic_media_pause
            else android.R.drawable.ic_media_play
        )
    }
    
    private fun updateSeekBar(position: Int) {
        binding.seekBar.progress = position
        binding.textCurrentTime.text = formatTime(position)
    }
    
    private fun updateTrackCount() {
        binding.textTrackCount.text = "Tracks: ${allTracks.size}"
        binding.progressBar.visibility = View.GONE
    }
    
    private fun formatTime(milliseconds: Int): String {
        val seconds = milliseconds / 1000
        val minutes = seconds / 60
        val remainingSeconds = seconds % 60
        return String.format("%d:%02d", minutes, remainingSeconds)
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        if (isBound) {
            context?.unbindService(serviceConnection)
            isBound = false
        }
        _binding = null
    }
}
