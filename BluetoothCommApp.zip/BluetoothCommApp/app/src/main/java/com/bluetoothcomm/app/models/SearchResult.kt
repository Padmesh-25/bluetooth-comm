package com.bluetoothcomm.app.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class SearchResult(
    val displayName: String,
    val latitude: Double,
    val longitude: Double,
    val type: String,
    val address: String = "",
    val distance: Double = 0.0
) : Parcelable
