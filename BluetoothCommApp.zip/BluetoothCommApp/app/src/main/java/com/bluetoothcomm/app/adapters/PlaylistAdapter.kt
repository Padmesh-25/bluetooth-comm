package com.bluetoothcomm.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bluetoothcomm.app.R
import com.bluetoothcomm.app.models.Playlist

class PlaylistAdapter(
    private val playlists: List<Playlist>,
    private val onPlaylistClick: (Playlist) -> Unit,
    private val onShareClick: (Playlist) -> Unit
) : RecyclerView.Adapter<PlaylistAdapter.PlaylistViewHolder>() {

    class PlaylistViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val playlistName: TextView = itemView.findViewById(R.id.text_playlist_name)
        val playlistDescription: TextView = itemView.findViewById(R.id.text_playlist_description)
        val trackCount: TextView = itemView.findViewById(R.id.text_track_count)
        val btnShare: ImageButton = itemView.findViewById(R.id.btn_share_playlist)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlaylistViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_playlist, parent, false)
        return PlaylistViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlaylistViewHolder, position: Int) {
        val playlist = playlists[position]
        
        holder.playlistName.text = playlist.name
        holder.playlistDescription.text = playlist.description.ifEmpty { "No description" }
        holder.trackCount.text = "${playlist.tracks.size} tracks"
        
        holder.itemView.setOnClickListener {
            onPlaylistClick(playlist)
        }
        
        holder.btnShare.setOnClickListener {
            onShareClick(playlist)
        }
    }

    override fun getItemCount() = playlists.size
}
