package com.bluetoothcomm.app.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
enum class AudioFormat : Parcelable {
    PCM_16BIT,
    PCM_8BIT,
    COMPRESSED_AAC,
    COMPRESSED_MP3
}
