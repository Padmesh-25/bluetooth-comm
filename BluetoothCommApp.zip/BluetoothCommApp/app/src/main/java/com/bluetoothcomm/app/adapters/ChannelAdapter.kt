package com.bluetoothcomm.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bluetoothcomm.app.R
import com.bluetoothcomm.app.models.VoiceChannel

class ChannelAdapter(
    private val channels: List<VoiceChannel>,
    private val onChannelClick: (VoiceChannel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.ChannelViewHolder>() {

    class ChannelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val channelName: TextView = itemView.findViewById(R.id.text_channel_name)
        val participantCount: TextView = itemView.findViewById(R.id.text_participant_count)
        val channelStatus: TextView = itemView.findViewById(R.id.text_channel_status)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_voice_channel, parent, false)
        return ChannelViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = channels[position]
        
        holder.channelName.text = channel.channelName
        holder.participantCount.text = "${channel.currentParticipants.size}/${channel.maxParticipants}"
        
        holder.channelStatus.text = when {
            channel.isPrivate -> "🔒 Private"
            channel.currentParticipants.size >= channel.maxParticipants -> "🚫 Full"
            else -> "🟢 Open"
        }
        
        holder.itemView.setOnClickListener {
            onChannelClick(channel)
        }
    }

    override fun getItemCount() = channels.size
}
