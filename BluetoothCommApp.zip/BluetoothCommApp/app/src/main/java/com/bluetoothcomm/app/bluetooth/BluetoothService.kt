package com.bluetoothcomm.app.bluetooth

import android.app.Service
import android.bluetooth.*
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.bluetoothcomm.app.models.DeviceInfo
import com.bluetoothcomm.app.models.VoiceMessage
import com.bluetoothcomm.app.models.LocationData
import com.google.gson.Gson
import java.io.*
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import kotlin.collections.ArrayList

class BluetoothService : Service() {
    
    companion object {
        private const val TAG = "BluetoothService"
        private const val APP_UUID = "550e8400-e29b-41d4-a716-446655440000"
        private const val SERVICE_NAME = "BluetoothCommApp"
        
        const val MESSAGE_TYPE_VOICE = "voice"
        const val MESSAGE_TYPE_LOCATION = "location"
        const val MESSAGE_TYPE_CHANNEL_JOIN = "channel_join"
        const val MESSAGE_TYPE_CHANNEL_LEAVE = "channel_leave"
        const val MESSAGE_TYPE_DEVICE_INFO = "device_info"
    }
    
    private val binder = LocalBinder()
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var serverSocket: BluetoothServerSocket? = null
    private var isListening = false
    
    // Connected devices and their sockets
    private val connectedDevices = ConcurrentHashMap<String, BluetoothSocket>()
    private val deviceInfoMap = ConcurrentHashMap<String, DeviceInfo>()
    
    // LiveData for UI updates
    val connectedDevicesList = MutableLiveData<List<DeviceInfo>>()
    val receivedMessages = MutableLiveData<VoiceMessage>()
    val locationUpdates = MutableLiveData<LocationData>()
    
    private val gson = Gson()
    
    inner class LocalBinder : Binder() {
        fun getService(): BluetoothService = this@BluetoothService
    }
    
    override fun onBind(intent: Intent): IBinder {
        return binder
    }
    
    override fun onCreate() {
        super.onCreate()
        initializeBluetooth()
        startListening()
    }
    
    private fun initializeBluetooth() {
        val bluetoothManager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
    }
    
    private fun startListening() {
        if (isListening) return
        
        Thread {
            try {
                val uuid = UUID.fromString(APP_UUID)
                serverSocket = bluetoothAdapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, uuid)
                isListening = true
                
                Log.d(TAG, "Server socket started, waiting for connections...")
                
                while (isListening) {
                    try {
                        val socket = serverSocket?.accept()
                        socket?.let { handleNewConnection(it) }
                    } catch (e: IOException) {
                        Log.e(TAG, "Error accepting connection", e)
                        break
                    }
                }
            } catch (e: IOException) {
                Log.e(TAG, "Error starting server socket", e)
            }
        }.start()
    }
    
    private fun handleNewConnection(socket: BluetoothSocket) {
        val deviceAddress = socket.remoteDevice.address
        connectedDevices[deviceAddress] = socket
        
        Log.d(TAG, "New device connected: $deviceAddress")
        
        // Start listening for messages from this device
        Thread {
            try {
                val inputStream = socket.inputStream
                val reader = BufferedReader(InputStreamReader(inputStream))
                
                while (socket.isConnected) {
                    try {
                        val message = reader.readLine()
                        if (message != null) {
                            handleReceivedMessage(deviceAddress, message)
                        }
                    } catch (e: IOException) {
                        Log.e(TAG, "Error reading from device $deviceAddress", e)
                        break
                    }
                }
            } catch (e: IOException) {
                Log.e(TAG, "Error setting up input stream for $deviceAddress", e)
            } finally {
                disconnectDevice(deviceAddress)
            }
        }.start()
        
        updateConnectedDevicesList()
    }
    
    private fun handleReceivedMessage(deviceAddress: String, message: String) {
        try {
            val messageData = gson.fromJson(message, Map::class.java)
            val messageType = messageData["type"] as? String
            
            when (messageType) {
                MESSAGE_TYPE_VOICE -> {
                    val voiceMessage = gson.fromJson(message, VoiceMessage::class.java)
                    receivedMessages.postValue(voiceMessage)
                    // Relay to other devices in the same channel
                    relayMessageToChannel(voiceMessage.channelId, message, deviceAddress)
                }
                MESSAGE_TYPE_LOCATION -> {
                    val locationData = gson.fromJson(message, LocationData::class.java)
                    locationUpdates.postValue(locationData)
                    // Update device info with location
                    deviceInfoMap[deviceAddress]?.let { deviceInfo ->
                        deviceInfo.latitude = locationData.latitude
                        deviceInfo.longitude = locationData.longitude
                        updateConnectedDevicesList()
                    }
                    // Relay to other devices
                    relayMessageToAll(message, deviceAddress)
                }
                MESSAGE_TYPE_DEVICE_INFO -> {
                    val deviceInfo = gson.fromJson(message, DeviceInfo::class.java)
                    deviceInfoMap[deviceAddress] = deviceInfo
                    updateConnectedDevicesList()
                }
                MESSAGE_TYPE_CHANNEL_JOIN, MESSAGE_TYPE_CHANNEL_LEAVE -> {
                    // Handle channel management
                    relayMessageToAll(message, deviceAddress)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing message from $deviceAddress", e)
        }
    }
    
    fun connectToDevice(device: BluetoothDevice) {
        Thread {
            try {
                val uuid = UUID.fromString(APP_UUID)
                val socket = device.createRfcommSocketToServiceRecord(uuid)
                socket.connect()
                
                val deviceAddress = device.address
                connectedDevices[deviceAddress] = socket
                
                Log.d(TAG, "Connected to device: $deviceAddress")
                handleNewConnection(socket)
                
            } catch (e: IOException) {
                Log.e(TAG, "Error connecting to device ${device.address}", e)
            }
        }.start()
    }
    
    fun sendMessage(message: Any, targetChannel: String? = null) {
        val jsonMessage = gson.toJson(message)
        
        if (targetChannel != null) {
            relayMessageToChannel(targetChannel, jsonMessage)
        } else {
            relayMessageToAll(jsonMessage)
        }
    }
    
    private fun relayMessageToChannel(channelId: String, message: String, excludeDevice: String? = null) {
        connectedDevices.forEach { (deviceAddress, socket) ->
            if (deviceAddress != excludeDevice) {
                val deviceInfo = deviceInfoMap[deviceAddress]
                if (deviceInfo?.currentChannel == channelId) {
                    sendMessageToDevice(socket, message)
                }
            }
        }
    }
    
    private fun relayMessageToAll(message: String, excludeDevice: String? = null) {
        connectedDevices.forEach { (deviceAddress, socket) ->
            if (deviceAddress != excludeDevice) {
                sendMessageToDevice(socket, message)
            }
        }
    }
    
    private fun sendMessageToDevice(socket: BluetoothSocket, message: String) {
        try {
            val outputStream = socket.outputStream
            val writer = PrintWriter(OutputStreamWriter(outputStream), true)
            writer.println(message)
        } catch (e: IOException) {
            Log.e(TAG, "Error sending message to device", e)
        }
    }
    
    private fun disconnectDevice(deviceAddress: String) {
        connectedDevices[deviceAddress]?.let { socket ->
            try {
                socket.close()
            } catch (e: IOException) {
                Log.e(TAG, "Error closing socket for $deviceAddress", e)
            }
        }
        connectedDevices.remove(deviceAddress)
        deviceInfoMap.remove(deviceAddress)
        updateConnectedDevicesList()
    }
    
    private fun updateConnectedDevicesList() {
        val devicesList = ArrayList(deviceInfoMap.values)
        connectedDevicesList.postValue(devicesList)
    }
    
    fun getConnectedDevices(): List<DeviceInfo> {
        return ArrayList(deviceInfoMap.values)
    }
    
    fun startDiscovery() {
        if (bluetoothAdapter.isDiscovering) {
            bluetoothAdapter.cancelDiscovery()
        }
        bluetoothAdapter.startDiscovery()
    }
    
    fun stopDiscovery() {
        if (bluetoothAdapter.isDiscovering) {
            bluetoothAdapter.cancelDiscovery()
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        isListening = false
        
        // Close all connections
        connectedDevices.values.forEach { socket ->
            try {
                socket.close()
            } catch (e: IOException) {
                Log.e(TAG, "Error closing socket", e)
            }
        }
        connectedDevices.clear()
        
        // Close server socket
        try {
            serverSocket?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error closing server socket", e)
        }
        
        stopDiscovery()
    }
}
