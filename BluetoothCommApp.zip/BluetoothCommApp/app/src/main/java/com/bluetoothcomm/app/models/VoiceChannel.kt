package com.bluetoothcomm.app.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class VoiceChannel(
    val channelId: String,
    val channelName: String,
    val createdBy: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isPrivate: Boolean = false,
    val password: String? = null,
    val maxParticipants: Int = 10,
    val currentParticipants: MutableList<String> = mutableListOf()
) : Parcelable
