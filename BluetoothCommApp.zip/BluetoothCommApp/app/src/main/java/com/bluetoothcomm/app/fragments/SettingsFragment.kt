package com.bluetoothcomm.app.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bluetoothcomm.app.R
import com.bluetoothcomm.app.databinding.FragmentSettingsBinding
import com.bluetoothcomm.app.utils.UserPreferences

class SettingsFragment : Fragment() {
    
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var userPreferences: UserPreferences
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        userPreferences = UserPreferences(requireContext())
        
        setupUI()
        loadUserSettings()
        setupClickListeners()
    }
    
    private fun setupUI() {
        // Set current app version
        val packageInfo = requireContext().packageManager.getPackageInfo(requireContext().packageName, 0)
        binding.textAppVersion.text = "Version ${packageInfo.versionName}"
        
        // Set default values if first time
        if (userPreferences.getUsername().isEmpty()) {
            binding.editUsername.setText("Rider${(1000..9999).random()}")
        }
    }
    
    private fun loadUserSettings() {
        // Load saved user preferences
        binding.editUsername.setText(userPreferences.getUsername())
        binding.editMobileNumber.setText(userPreferences.getMobileNumber())
        binding.editDisplayName.setText(userPreferences.getDisplayName())
        
        // Load app preferences
        binding.switchVoiceNotifications.isChecked = userPreferences.isVoiceNotificationsEnabled()
        binding.switchLocationSharing.isChecked = userPreferences.isLocationSharingEnabled()
        binding.switchAutoJoinLastChannel.isChecked = userPreferences.isAutoJoinLastChannelEnabled()
        binding.switchKeepScreenOn.isChecked = userPreferences.isKeepScreenOnEnabled()
        
        // Load audio settings
        binding.seekBarMicSensitivity.progress = userPreferences.getMicSensitivity()
        binding.seekBarSpeakerVolume.progress = userPreferences.getSpeakerVolume()
        
        updateSensitivityLabel(userPreferences.getMicSensitivity())
        updateVolumeLabel(userPreferences.getSpeakerVolume())
    }
    
    private fun setupClickListeners() {
        // Save user info
        binding.btnSaveUserInfo.setOnClickListener {
            saveUserInfo()
        }
        
        // Clear user data
        binding.btnClearData.setOnClickListener {
            clearUserData()
        }
        
        // Export settings
        binding.btnExportSettings.setOnClickListener {
            exportSettings()
        }
        
        // Reset to defaults
        binding.btnResetDefaults.setOnClickListener {
            resetToDefaults()
        }
        
        // App preferences switches
        binding.switchVoiceNotifications.setOnCheckedChangeListener { _, isChecked ->
            userPreferences.setVoiceNotificationsEnabled(isChecked)
            showToast(if (isChecked) "Voice notifications enabled" else "Voice notifications disabled")
        }
        
        binding.switchLocationSharing.setOnCheckedChangeListener { _, isChecked ->
            userPreferences.setLocationSharingEnabled(isChecked)
            showToast(if (isChecked) "Location sharing enabled" else "Location sharing disabled")
        }
        
        binding.switchAutoJoinLastChannel.setOnCheckedChangeListener { _, isChecked ->
            userPreferences.setAutoJoinLastChannelEnabled(isChecked)
            showToast(if (isChecked) "Auto-join last channel enabled" else "Auto-join last channel disabled")
        }
        
        binding.switchKeepScreenOn.setOnCheckedChangeListener { _, isChecked ->
            userPreferences.setKeepScreenOnEnabled(isChecked)
            showToast(if (isChecked) "Keep screen on enabled" else "Keep screen on disabled")
        }
        
        // Audio settings
        binding.seekBarMicSensitivity.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    updateSensitivityLabel(progress)
                    userPreferences.setMicSensitivity(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
        
        binding.seekBarSpeakerVolume.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    updateVolumeLabel(progress)
                    userPreferences.setSpeakerVolume(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
    }
    
    private fun saveUserInfo() {
        val username = binding.editUsername.text.toString().trim()
        val mobileNumber = binding.editMobileNumber.text.toString().trim()
        val displayName = binding.editDisplayName.text.toString().trim()
        
        // Validate input
        if (username.isEmpty()) {
            binding.editUsername.error = "Username is required"
            return
        }
        
        if (username.length < 3) {
            binding.editUsername.error = "Username must be at least 3 characters"
            return
        }
        
        if (mobileNumber.isNotEmpty() && !isValidMobileNumber(mobileNumber)) {
            binding.editMobileNumber.error = "Please enter a valid mobile number"
            return
        }
        
        // Save to preferences
        userPreferences.setUsername(username)
        userPreferences.setMobileNumber(mobileNumber)
        userPreferences.setDisplayName(displayName.ifEmpty { username })
        
        showToast("User information saved successfully!")
        
        // Update device info for other fragments
        updateDeviceInfo()
    }
    
    private fun clearUserData() {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Clear User Data")
            .setMessage("This will clear all your user information and app preferences. Are you sure?")
            .setPositiveButton("Clear") { _, _ ->
                userPreferences.clearAll()
                loadUserSettings()
                showToast("User data cleared")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun exportSettings() {
        val settings = userPreferences.exportSettings()
        
        // Create sharing intent
        val shareIntent = android.content.Intent().apply {
            action = android.content.Intent.ACTION_SEND
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, settings)
            putExtra(android.content.Intent.EXTRA_SUBJECT, "Bluetooth Comm App Settings")
        }
        
        startActivity(android.content.Intent.createChooser(shareIntent, "Export Settings"))
    }
    
    private fun resetToDefaults() {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Reset to Defaults")
            .setMessage("This will reset all app preferences to default values. User information will be kept.")
            .setPositiveButton("Reset") { _, _ ->
                userPreferences.resetToDefaults()
                loadUserSettings()
                showToast("Settings reset to defaults")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun updateSensitivityLabel(progress: Int) {
        val sensitivity = when (progress) {
            in 0..20 -> "Very Low"
            in 21..40 -> "Low"
            in 41..60 -> "Medium"
            in 61..80 -> "High"
            else -> "Very High"
        }
        binding.textMicSensitivityLabel.text = "Microphone Sensitivity: $sensitivity"
    }
    
    private fun updateVolumeLabel(progress: Int) {
        val volume = when (progress) {
            in 0..20 -> "Very Low"
            in 21..40 -> "Low"
            in 41..60 -> "Medium"
            in 61..80 -> "High"
            else -> "Very High"
        }
        binding.textSpeakerVolumeLabel.text = "Speaker Volume: $volume"
    }
    
    private fun isValidMobileNumber(number: String): Boolean {
        // Basic mobile number validation (10-15 digits)
        return number.matches(Regex("^[+]?[0-9]{10,15}$"))
    }
    
    private fun updateDeviceInfo() {
        // Broadcast user info update to other components
        val intent = android.content.Intent("USER_INFO_UPDATED")
        requireContext().sendBroadcast(intent)
    }
    
    private fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
