package com.bluetoothcomm.app.music

import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.bluetoothcomm.app.models.MusicTrack
import java.io.IOException

class MusicService : Service(), MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener {
    
    companion object {
        private const val TAG = "MusicService"
        private const val UPDATE_INTERVAL = 1000L
    }
    
    private val binder = LocalBinder()
    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var updateRunnable: Runnable? = null
    
    // LiveData for UI updates
    val currentTrack = MutableLiveData<MusicTrack?>()
    val isPlaying = MutableLiveData<Boolean>()
    val currentPosition = MutableLiveData<Int>()
    val duration = MutableLiveData<Int>()
    
    private var currentPlayingTrack: MusicTrack? = null
    private var playlist: List<MusicTrack> = emptyList()
    private var currentIndex = 0
    
    inner class LocalBinder : Binder() {
        fun getService(): MusicService = this@MusicService
    }
    
    override fun onBind(intent: Intent): IBinder {
        return binder
    }
    
    override fun onCreate() {
        super.onCreate()
        initializeMediaPlayer()
        startPositionUpdates()
    }
    
    private fun initializeMediaPlayer() {
        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            setOnCompletionListener(this@MusicService)
            setOnErrorListener(this@MusicService)
        }
    }
    
    fun playTrack(track: MusicTrack) {
        try {
            mediaPlayer?.reset()
            mediaPlayer?.setDataSource(track.filePath)
            mediaPlayer?.prepareAsync()
            
            mediaPlayer?.setOnPreparedListener { mp ->
                mp.start()
                currentPlayingTrack = track
                currentTrack.postValue(track)
                isPlaying.postValue(true)
                duration.postValue(mp.duration)
                
                Log.d(TAG, "Playing track: ${track.title}")
            }
            
        } catch (e: IOException) {
            Log.e(TAG, "Error playing track: ${track.title}", e)
        }
    }
    
    fun playPlaylist(tracks: List<MusicTrack>, startIndex: Int = 0) {
        playlist = tracks
        currentIndex = startIndex.coerceIn(0, tracks.size - 1)
        
        if (tracks.isNotEmpty()) {
            playTrack(tracks[currentIndex])
        }
    }
    
    fun pause() {
        mediaPlayer?.let { mp ->
            if (mp.isPlaying) {
                mp.pause()
                isPlaying.postValue(false)
                Log.d(TAG, "Playback paused")
            }
        }
    }
    
    fun resume() {
        mediaPlayer?.let { mp ->
            if (!mp.isPlaying) {
                mp.start()
                isPlaying.postValue(true)
                Log.d(TAG, "Playback resumed")
            }
        }
    }
    
    fun stop() {
        mediaPlayer?.let { mp ->
            if (mp.isPlaying) {
                mp.stop()
                mp.reset()
                isPlaying.postValue(false)
                currentTrack.postValue(null)
                currentPosition.postValue(0)
                Log.d(TAG, "Playback stopped")
            }
        }
    }
    
    fun seekTo(position: Int) {
        mediaPlayer?.seekTo(position)
        currentPosition.postValue(position)
    }
    
    fun playNext() {
        if (playlist.isNotEmpty() && currentIndex < playlist.size - 1) {
            currentIndex++
            playTrack(playlist[currentIndex])
        } else if (playlist.isNotEmpty()) {
            // Loop back to beginning
            currentIndex = 0
            playTrack(playlist[currentIndex])
        }
    }
    
    fun playPrevious() {
        if (playlist.isNotEmpty() && currentIndex > 0) {
            currentIndex--
            playTrack(playlist[currentIndex])
        } else if (playlist.isNotEmpty()) {
            // Loop to end
            currentIndex = playlist.size - 1
            playTrack(playlist[currentIndex])
        }
    }
    
    fun setVolume(volume: Float) {
        val clampedVolume = volume.coerceIn(0f, 1f)
        mediaPlayer?.setVolume(clampedVolume, clampedVolume)
    }
    
    fun getCurrentPosition(): Int {
        return mediaPlayer?.currentPosition ?: 0
    }
    
    fun getDuration(): Int {
        return mediaPlayer?.duration ?: 0
    }
    
    fun isCurrentlyPlaying(): Boolean {
        return mediaPlayer?.isPlaying ?: false
    }
    
    private fun startPositionUpdates() {
        updateRunnable = object : Runnable {
            override fun run() {
                mediaPlayer?.let { mp ->
                    if (mp.isPlaying) {
                        currentPosition.postValue(mp.currentPosition)
                    }
                }
                handler.postDelayed(this, UPDATE_INTERVAL)
            }
        }
        handler.post(updateRunnable!!)
    }
    
    override fun onCompletion(mp: MediaPlayer?) {
        Log.d(TAG, "Track completed")
        
        // Auto-play next track if in playlist mode
        if (playlist.isNotEmpty()) {
            playNext()
        } else {
            isPlaying.postValue(false)
            currentPosition.postValue(0)
        }
    }
    
    override fun onError(mp: MediaPlayer?, what: Int, extra: Int): Boolean {
        Log.e(TAG, "MediaPlayer error: what=$what, extra=$extra")
        
        // Try to recover by playing next track
        if (playlist.isNotEmpty()) {
            playNext()
            return true
        }
        
        return false
    }
    
    fun shuffle() {
        if (playlist.isNotEmpty()) {
            val shuffledPlaylist = playlist.shuffled()
            playPlaylist(shuffledPlaylist, 0)
        }
    }
    
    fun repeat(mode: RepeatMode) {
        // Implementation for repeat modes
        when (mode) {
            RepeatMode.OFF -> {
                // Normal playback
            }
            RepeatMode.ONE -> {
                // Repeat current track
            }
            RepeatMode.ALL -> {
                // Repeat entire playlist
            }
        }
    }
    
    enum class RepeatMode {
        OFF, ONE, ALL
    }
    
    override fun onDestroy() {
        super.onDestroy()
        
        updateRunnable?.let { handler.removeCallbacks(it) }
        
        mediaPlayer?.let { mp ->
            if (mp.isPlaying) {
                mp.stop()
            }
            mp.release()
        }
        mediaPlayer = null
        
        Log.d(TAG, "MusicService destroyed")
    }
}
