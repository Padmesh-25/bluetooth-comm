package com.bluetoothcomm.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bluetoothcomm.app.R
import com.bluetoothcomm.app.models.DeviceInfo

class ConnectedDevicesAdapter(
    private var devices: List<DeviceInfo>,
    private val onDeviceClick: (DeviceInfo) -> Unit
) : RecyclerView.Adapter<ConnectedDevicesAdapter.DeviceViewHolder>() {

    class DeviceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val deviceName: TextView = itemView.findViewById(R.id.text_device_name)
        val deviceStatus: TextView = itemView.findViewById(R.id.text_device_status)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_connected_device, parent, false)
        return DeviceViewHolder(view)
    }

    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
        val device = devices[position]
        
        // Display username if available, otherwise device name
        holder.deviceName.text = device.getShortIdentifier()
        
        // Show channel status and additional info
        holder.deviceStatus.text = when {
            device.currentChannel != null -> "📻 ${device.currentChannel}"
            device.username.isNotEmpty() -> "👤 ${device.username}"
            else -> "⚪ No channel"
        }
        
        // Set background color based on connection status
        val backgroundColor = if (device.isConnected) {
            holder.itemView.context.getColor(R.color.device_marker_online)
        } else {
            holder.itemView.context.getColor(R.color.device_marker_offline)
        }
        holder.itemView.setBackgroundColor(backgroundColor)
        
        holder.itemView.setOnClickListener {
            onDeviceClick(device)
        }
    }

    override fun getItemCount() = devices.size
    
    fun updateDevices(newDevices: List<DeviceInfo>) {
        devices = newDevices
        notifyDataSetChanged()
    }
}
