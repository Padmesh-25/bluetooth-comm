# Bluetooth Communication App

A comprehensive Android application that enables Bluetooth-based communication between mobile devices without requiring an internet connection. The app features voice channels, offline maps with device tracking, and a music player with playlist sharing capabilities.

## Features

### 🎙️ Voice Channel Communication
- **Radio-like Communication**: Push-to-talk functionality for voice communication
- **Channel Management**: Create, join, and leave voice channels
- **Multi-device Support**: Communicate with multiple devices simultaneously
- **Real-time Audio**: Low-latency voice transmission over Bluetooth
- **Channel Types**: Support for both public and private (password-protected) channels

### 🗺️ Offline Maps with Device Tracking
- **OpenStreetMap Integration**: Free offline maps using OSMDroid
- **Device Location Sharing**: Real-time location sharing between connected devices
- **Visual Device Tracking**: See all connected devices on the map with their current locations
- **Offline Mode**: Full functionality without internet connection
- **Location Accuracy**: GPS-based precise location tracking

### 🎵 Offline Music Player
- **Local Music Library**: Scan and play music files from device storage
- **Playlist Management**: Create, edit, and manage custom playlists
- **Social Sharing**: Share playlists via WhatsApp, SMS, or other communication apps
- **Audio Controls**: Full playback controls with seek functionality
- **Format Support**: Supports common audio formats (MP3, AAC, etc.)

### 📡 Bluetooth Communication
- **Device Discovery**: Automatic discovery of nearby Bluetooth-enabled devices
- **Secure Connections**: Encrypted Bluetooth communication
- **Connection Management**: Automatic reconnection and connection monitoring
- **Multi-device Support**: Connect to multiple devices simultaneously
- **Range Optimization**: Optimized for Bluetooth Classic range (~10-100 meters)

## Technical Architecture

### Core Components

1. **BluetoothService**: Manages device discovery, connections, and message routing
2. **VoiceService**: Handles audio recording, processing, and playback
3. **MusicService**: Manages music playback and playlist operations
4. **LocationManager**: GPS tracking and location sharing functionality

### Key Technologies

- **Bluetooth Classic**: For reliable device-to-device communication
- **OSMDroid**: Free OpenStreetMap implementation for offline maps
- **MediaPlayer/AudioRecord**: Native Android audio APIs
- **Room Database**: Local data persistence
- **Kotlin Coroutines**: Asynchronous operations
- **Material Design**: Modern UI/UX components

## Installation & Setup

### Prerequisites
- Android device with API level 23+ (Android 6.0+)
- Bluetooth capability
- GPS/Location services
- Microphone access
- Storage access for music files

### Building the App

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd BluetoothCommApp
   ```

2. **Open in Android Studio**
   - Import the project in Android Studio
   - Sync Gradle files
   - Ensure all dependencies are downloaded

3. **Build and Install**
   ```bash
   ./gradlew assembleDebug
   ./gradlew installDebug
   ```

### Required Permissions

The app requires the following permissions:
- `BLUETOOTH` & `BLUETOOTH_ADMIN` - For Bluetooth communication
- `BLUETOOTH_SCAN`, `BLUETOOTH_CONNECT`, `BLUETOOTH_ADVERTISE` - For Android 12+
- `ACCESS_FINE_LOCATION` - For device discovery and GPS
- `RECORD_AUDIO` - For voice communication
- `READ_EXTERNAL_STORAGE` - For music file access
- `INTERNET` - For playlist sharing (optional)

## Usage Guide

### Getting Started

1. **Launch the App**: Open the Bluetooth Communication App
2. **Grant Permissions**: Allow all required permissions when prompted
3. **Enable Bluetooth**: The app will prompt to enable Bluetooth if not already on

### Voice Communication

1. **Discover Devices**: Tap "Discover Devices" to find nearby devices
2. **Create/Join Channel**: 
   - Create a new channel with "Create Channel"
   - Join an existing channel by tapping on it
3. **Push-to-Talk**: Hold the large circular button to record and transmit voice
4. **Leave Channel**: Use "Leave Channel" button when done

### Map Features

1. **View Connected Devices**: All connected devices appear as markers on the map
2. **Share Location**: Tap "Share Location" to broadcast your current position
3. **Center on Location**: Use "Center on Me" to focus map on your location
4. **Offline Mode**: Toggle between online and offline map modes

### Music Player

1. **Scan Music**: Tap "Scan" to find music files on your device
2. **Create Playlists**: Use "Create Playlist" to organize your music
3. **Play Music**: Tap any track to start playback
4. **Share Playlists**: Use the share button to send playlists via other apps

## API Usage

### Free APIs Used

- **OpenStreetMap (OSMDroid)**: Free map tiles and offline mapping
- **Android MediaStore**: Built-in music file scanning
- **Android Location Services**: GPS and location APIs
- **Android Bluetooth APIs**: Native Bluetooth communication

### No API Keys Required

This app is designed to work completely offline and uses only free, public APIs that don't require API keys or registration.

## Development

### Project Structure

```
app/
├── src/main/java/com/bluetoothcomm/app/
│   ├── MainActivity.kt                 # Main entry point
│   ├── bluetooth/
│   │   └── BluetoothService.kt        # Bluetooth communication
│   ├── voice/
│   │   └── VoiceService.kt            # Audio handling
│   ├── music/
│   │   └── MusicService.kt            # Music playback
│   ├── fragments/
│   │   ├── VoiceChannelFragment.kt    # Voice UI
│   │   ├── MapFragment.kt             # Map UI
│   │   └── MusicPlayerFragment.kt     # Music UI
│   ├── models/                        # Data models
│   ├── adapters/                      # RecyclerView adapters
│   ├── dialogs/                       # Dialog fragments
│   └── utils/                         # Utility classes
├── src/main/res/                      # Resources (layouts, drawables, etc.)
└── build.gradle                       # App dependencies
```

### Key Classes

- **MainActivity**: Main activity with bottom navigation
- **BluetoothService**: Core Bluetooth communication service
- **VoiceService**: Audio recording and playback management
- **MusicService**: Music player functionality
- **MusicScanner**: Utility for scanning device music files

## Troubleshooting

### Common Issues

1. **Bluetooth Connection Failed**
   - Ensure both devices have Bluetooth enabled
   - Check if devices are in discoverable mode
   - Verify location permissions are granted

2. **Voice Not Working**
   - Check microphone permissions
   - Ensure devices are in the same voice channel
   - Verify audio recording permissions

3. **Map Not Loading**
   - Check location permissions
   - Ensure GPS is enabled
   - Try toggling online/offline mode

4. **Music Not Found**
   - Grant storage permissions
   - Use "Scan Music" to refresh library
   - Check if music files are in supported formats

### Performance Tips

- Keep Bluetooth discovery time limited to save battery
- Use offline map mode when internet is not available
- Close unused voice channels to reduce battery drain
- Regularly clear app cache if experiencing slowdowns

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/new-feature`)
3. Commit changes (`git commit -am 'Add new feature'`)
4. Push to branch (`git push origin feature/new-feature`)
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- OpenStreetMap contributors for free map data
- OSMDroid library for offline mapping capabilities
- Android Open Source Project for Bluetooth and audio APIs
- Material Design team for UI components

## Support

For issues, questions, or contributions, please create an issue in the repository or contact the development team.

---

**Note**: This app is designed for offline, peer-to-peer communication and does not require internet connectivity for core functionality. Playlist sharing features require internet access to use third-party messaging apps.
