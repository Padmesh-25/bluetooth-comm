# Settings Guide - Bluetooth Communication App

## ⚙️ Complete Settings Menu for User Identification

The app now includes a comprehensive settings menu that allows users to configure their identity for better communication and identification in voice channels.

## 👤 User Information Settings

### **Username Configuration**
- **Purpose**: Primary identifier visible to other riders in voice channels
- **Requirements**: 3-20 characters, unique within your riding group
- **Visibility**: Shown when you speak, in device lists, and channel participants
- **Default**: Auto-generated (e.g., "Rider1234") on first launch

### **Display Name (Optional)**
- **Purpose**: Friendly name that appears alongside username
- **Format**: "Display Name (username)" in channel lists
- **Use Case**: Use real name while keeping unique username
- **Example**: "John Smith (BikerJohn)" or "Mike (Rider007)"

### **Mobile Number (Optional)**
- **Purpose**: Additional identification and emergency contact
- **Format**: International format recommended (+1234567890)
- **Visibility**: Shown in device details and emergency situations
- **Privacy**: Only visible to connected devices in your channels

## 🎛️ App Preferences

### **Voice Notifications**
- **Default**: Enabled
- **Function**: Audio alerts for channel events and messages
- **When Disabled**: Silent operation, visual indicators only
- **Bike Rider Benefit**: Reduces audio distractions while riding

### **Location Sharing**
- **Default**: Enabled
- **Function**: Automatically shares GPS location with channel members
- **Privacy**: Only shared with devices in same voice channel
- **Safety**: Essential for group rides and emergency situations

### **Auto-join Last Channel**
- **Default**: Disabled
- **Function**: Automatically rejoin last used channel on app startup
- **Use Case**: Regular riding groups with consistent channels
- **Convenience**: Reduces setup time for frequent riders

### **Keep Screen On**
- **Default**: Disabled
- **Function**: Prevents screen from turning off during use
- **Battery Impact**: Increases battery consumption
- **Riding Benefit**: Screen always visible for navigation and controls

## 🎵 Audio Settings

### **Microphone Sensitivity**
- **Range**: Very Low to Very High (0-100%)
- **Default**: Medium (50%)
- **Purpose**: Adjusts how sensitive the mic is to your voice
- **Bike Riding**: Higher sensitivity for helmet/wind noise compensation
- **Recommendations**:
  - **Open Helmet**: Medium (40-60%)
  - **Full Face Helmet**: High (60-80%)
  - **Windy Conditions**: Very High (80-100%)

### **Speaker Volume**
- **Range**: Very Low to Very High (0-100%)
- **Default**: High (70%)
- **Purpose**: Controls volume of incoming voice messages
- **Safety**: Ensure you can still hear traffic and environment
- **Recommendations**:
  - **City Riding**: Medium (40-60%)
  - **Highway Riding**: High (60-80%)
  - **Quiet Roads**: Low to Medium (20-50%)

## 🔧 Actions & Management

### **Export Settings**
- **Function**: Creates shareable text with all your settings
- **Use Cases**: 
  - Backup before app updates
  - Share configuration with riding group
  - Transfer settings to new device
- **Format**: JSON text that can be shared via any messaging app

### **Reset to Defaults**
- **Function**: Restores all app preferences to factory settings
- **Preserved**: User information (username, display name, mobile)
- **Reset**: Audio settings, app preferences, channel history
- **Use Case**: Troubleshooting audio or performance issues

### **Clear All Data**
- **Function**: Completely wipes all user data and preferences
- **Warning**: Irreversible action - everything is deleted
- **Use Cases**: 
  - Selling/giving away device
  - Starting fresh with new identity
  - Privacy concerns

## 🏍️ Settings for Bike Riders

### **Pre-Ride Setup Checklist**
1. **Configure Username**: Set recognizable name for your group
2. **Test Audio Levels**: Adjust mic sensitivity for your helmet
3. **Enable Location Sharing**: Essential for group coordination
4. **Set Speaker Volume**: Balance communication with safety
5. **Save Settings**: Export configuration as backup

### **Recommended Settings by Riding Type**

#### **City Group Rides**
- Microphone Sensitivity: Medium (50%)
- Speaker Volume: Medium (50%)
- Voice Notifications: Enabled
- Keep Screen On: Disabled (save battery)

#### **Highway Touring**
- Microphone Sensitivity: High (70%)
- Speaker Volume: High (70%)
- Auto-join Last Channel: Enabled
- Location Sharing: Enabled (safety)

#### **Off-Road Adventures**
- Microphone Sensitivity: Very High (80%)
- Speaker Volume: High (75%)
- Keep Screen On: Enabled (navigation)
- Location Sharing: Enabled (emergency)

### **Emergency Settings**
- Always keep Location Sharing enabled
- Set mobile number for emergency identification
- Use clear, recognizable username
- Test audio settings before remote rides

## 📱 User Identification Features

### **In Voice Channels**
- **Speaker Identification**: "John Smith is speaking" or "BikerJohn is speaking"
- **Channel Participants**: List shows all usernames/display names
- **Device Lists**: Connected devices show user identities
- **Voice Messages**: Each message tagged with speaker name

### **On Maps**
- **Device Markers**: Show username instead of device name
- **Location Pins**: Labeled with user identifiers
- **Group Tracking**: Easy identification of group members
- **Emergency Coordination**: Quick identification for help

### **Privacy & Security**
- **Local Storage**: All settings stored locally on device
- **No Cloud Sync**: Settings don't leave your device
- **Bluetooth Only**: User info only shared via Bluetooth
- **Group Visibility**: Only visible to connected channel members

## 🔄 Settings Sync & Backup

### **Manual Backup**
1. Go to Settings → Actions
2. Tap "Export Settings"
3. Share via WhatsApp, email, or save to notes
4. Keep backup for device changes or app reinstalls

### **Restore Settings**
1. Install app on new device
2. Open Settings
3. Manually enter user information
4. Adjust audio settings based on exported backup
5. Test with riding group before important rides

## 🚀 Quick Setup for New Users

### **First Time Setup (2 minutes)**
1. **Open Settings**: Tap settings icon in bottom navigation
2. **Enter Username**: Choose unique, recognizable name
3. **Add Display Name**: Optional friendly name
4. **Set Mobile Number**: For emergency identification
5. **Test Audio**: Adjust mic sensitivity and speaker volume
6. **Save Settings**: Tap "Save User Information"

### **Join Group Ride**
1. Share username with group leader
2. Join voice channel created by group
3. Test communication before departure
4. Verify location sharing is working
5. Ready to ride safely with communication!

---

**Pro Tip**: Always test your settings with your riding group before heading out on important rides. Audio levels that work in your garage might need adjustment with helmet and wind noise!
